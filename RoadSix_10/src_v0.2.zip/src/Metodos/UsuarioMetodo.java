package Metodos;
import Conexao.Conexao;
import Class.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
public class UsuarioMetodo {
    Usuario user = new Usuario();
    Connection conexao = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
	
// Metodo para consulta 
    private void consulta(Usuario user){
        Conexao.conector();
        String consult= "select * from USUARIO where nome =? ";
        try {
            pst=conexao.prepareStatement(consult);
            pst.setString(1, user.getNome());
            rs = pst.executeQuery();
            if (rs.next()) {
                user.setNome(rs.getString(1));
                user.setCargo(rs.getString(2));
                user.setLogin(rs.getString(3));
                user.setSenha(rs.getString(4));
                user.setEmail(rs.getString(5));
            } else {
                JOptionPane.showMessageDialog(null," Usuario não localizado!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"Erro");
        }
    }

// Metodo para adcionar Ok
    private void adcionar(Usuario user){
        Conexao.conector();
        String add= " insert into USUARIO (nome,cargo,login,senha,email) VALUES (?,?,?,?,?)";
        try {
            pst=conexao.prepareStatement(add);
            pst.setString(1,user.getNome());
            pst.setString(2,user.getCargo());
            pst.setString(3,user.getLogin());
            pst.setString(4,user.getSenha());
            pst.setString(5,user.getEmail());
            int addd = pst.executeUpdate();
            if(addd >0){
                JOptionPane.showMessageDialog(null," Usuario cadastrado!");
                user.setNome(null);
                user.setCargo(null);
                user.setLogin(null);
                user.setSenha(null);
                user.setEmail(null);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"Usuario já existe");
        }
    }

// Metodo para alterar Ok
    private void alterar(Usuario user){
        Conexao.conector();
        String alterar= " update USUARIO set cargo=?,login=?,senha=?,email=? where nome=?";
        try {
            pst=conexao.prepareStatement(alterar);
            pst.setString(1,user.getNome());
            pst.setString(2,user.getCargo());
            pst.setString(3,user.getLogin());
            pst.setString(4,user.getSenha());
            pst.setString(5,user.getEmail());
            int alt = pst.executeUpdate();
            if(alt>0){
                JOptionPane.showMessageDialog(null," Usuario alterado!");
                user.setNome(null);
                user.setCargo(null);
                user.setLogin(null);
                user.setSenha(null);
                user.setEmail(null);
            }       
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,e);
        }
}

// Metodo para excluir Ok
    private void excluir(Usuario user){
        Conexao.conector();
        int confirmar = JOptionPane.showConfirmDialog(null,"Tem certeza que deseja excluir esse usuario ? ","Atenção!!!", JOptionPane.YES_NO_OPTION );
        if(confirmar == JOptionPane.YES_NO_OPTION){
            String del= "delete from USUARIO where nome=?";
            try {
                pst=conexao.prepareStatement(del);
                pst.setString(1, user.getNome());
                int ex = pst.executeUpdate();
                    if(ex>0){
                        JOptionPane.showMessageDialog(null," Usuario apagado");
                    }
            } catch (SQLException e) {
                JOptionPane.showConfirmDialog(null,"Esse usuario não existe ");
            }
        }
}
}

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
	

  
    

