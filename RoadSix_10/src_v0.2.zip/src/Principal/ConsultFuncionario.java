package Principal;


import Principal.TelaPrincipal;
import Conexao.Conexao;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class ConsultFuncionario extends javax.swing.JInternalFrame {
    
    private static ConsultFuncionario instancia = null;
    
    ConsultFuncionario_editar frame2 = new ConsultFuncionario_editar();
    
    public ConsultFuncionario() {
        initComponents();
        conexao = Conexao.conector();
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(150, 100);
    }
    
    Connection conexao = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    
    public static ConsultFuncionario getInstancia() {
        if(instancia == null) {
            instancia = new ConsultFuncionario();
        }
        return instancia;
    }
    
    private void consulta(){
	String consult= "select * from USUARIO where nome =? ";
	try {
            pst=conexao.prepareStatement(consult);
            pst.setString(1,procuraNome.getText());
            rs = pst.executeQuery();
            if (rs.next()) {
                ShowNome.setText(rs.getString(1));
		ShowCargo.setText(rs.getString(2));
		ShowLogin.setText(rs.getString(3));
		ShowEmail.setText(rs.getString(5));		
		} else {
                    JOptionPane.showMessageDialog(null," Usuario não localizado!");
		}
	} catch (SQLException e) {
            JOptionPane.showMessageDialog(null,e);
	}
    }
    
    private void excluir(){
		int confirmar = JOptionPane.showConfirmDialog(null,"Tem certeza que deseja excluir esse usuario ? ","Atenção!!!", JOptionPane.YES_NO_OPTION );
		if(confirmar == JOptionPane.YES_NO_OPTION){
		String del= "delete from USUARIO where nome=?";
			try {
				pst=conexao.prepareStatement(del);
				pst.setString(1, procuraNome.getText());
				int ex = pst.executeUpdate();
				if(ex>0){
				JOptionPane.showMessageDialog(null," Usuario apagado");
				}
			} catch (SQLException e) {}
		}
		
	}

    public JLabel getShowCargo() {
        return ShowCargo;
    }

    public void setShowCargo(JLabel ShowCargo) {
        this.ShowCargo = ShowCargo;
    }

    public JLabel getShowEmail() {
        return ShowEmail;
    }

    public void setShowEmail(JLabel ShowEmail) {
        this.ShowEmail = ShowEmail;
    }

    public JLabel getShowLogin() {
        return ShowLogin;
    }

    public void setShowLogin(JLabel ShowLogin) {
        this.ShowLogin = ShowLogin;
    }

    public JLabel getShowNome() {
        return ShowNome;
    }

    public void setShowNome(JLabel ShowNome) {
        this.ShowNome = ShowNome;
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        procuraNome = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel6 = new javax.swing.JLabel();
        ShowNome = new javax.swing.JLabel();
        ShowCargo = new javax.swing.JLabel();
        ShowLogin = new javax.swing.JLabel();
        ShowEmail = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        excluirFuncionario = new javax.swing.JButton();
        procurar = new javax.swing.JButton();
        Cancelar = new javax.swing.JButton();

        jLabel2.setText("Pesquisar nome:");

        jLabel3.setText("Cargo:");

        jLabel4.setText("Login:");

        jLabel5.setText("E-mail:");

        jLabel6.setText("Nome:");

        jButton1.setText("Editar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editar(evt);
            }
        });

        excluirFuncionario.setText("Excluir");
        excluirFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                excluir(evt);
            }
        });

        procurar.setText("Pesquisar");
        procurar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                procurarNome(evt);
            }
        });

        Cancelar.setText("Cancelar");
        Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 599, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(30, 30, 30)
                                .addComponent(ShowNome))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel3))
                                .addGap(28, 28, 28)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(ShowCargo)
                                    .addComponent(ShowLogin)
                                    .addComponent(ShowEmail)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(procuraNome, javax.swing.GroupLayout.PREFERRED_SIZE, 354, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(procurar)))
                        .addGap(19, 19, 19))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(264, 264, 264)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Cancelar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(excluirFuncionario)))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(procuraNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(procurar))
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(ShowNome))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(ShowCargo))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(ShowLogin))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(ShowEmail))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 64, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(excluirFuncionario)
                    .addComponent(Cancelar))
                .addGap(28, 28, 28))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void procurarNome(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_procurarNome
        consulta();
    }//GEN-LAST:event_procurarNome

    private void excluir(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_excluir
        excluir();
    }//GEN-LAST:event_excluir

    private void editar(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editar

        if(!ConsultFuncionario_editar.getInstancia().isVisible()){
            TelaPrincipal.Painel.add(ConsultFuncionario_editar.getInstancia());
            ConsultFuncionario_editar.getInstancia().setVisible(true);
        } else {
            ConsultFuncionario_editar.getInstancia().requestFocus();
        }
    }//GEN-LAST:event_editar

    private void CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelarActionPerformed
        procuraNome.setText(null);
        ShowNome.setText(null);
        ShowCargo.setText(null);
        ShowLogin.setText(null);
        ShowEmail.setText(null);
        dispose();
    }//GEN-LAST:event_CancelarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cancelar;
    private javax.swing.JLabel ShowCargo;
    private javax.swing.JLabel ShowEmail;
    private javax.swing.JLabel ShowLogin;
    private javax.swing.JLabel ShowNome;
    private javax.swing.JButton excluirFuncionario;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField procuraNome;
    private javax.swing.JButton procurar;
    // End of variables declaration//GEN-END:variables
}
